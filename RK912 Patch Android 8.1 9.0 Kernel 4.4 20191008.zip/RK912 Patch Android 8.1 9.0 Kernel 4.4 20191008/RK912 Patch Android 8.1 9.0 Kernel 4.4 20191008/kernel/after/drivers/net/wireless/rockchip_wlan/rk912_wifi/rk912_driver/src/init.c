#include <linux/module.h>
#include <net/mac80211.h>
#include <linux/time.h>
#include <linux/pm.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/syscalls.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/workqueue.h>
#include <linux/platform_device.h>
#include <linux/suspend.h>
#include <linux/of.h>
#include <linux/io.h>
#include <linux/of_address.h>
#include <linux/delay.h>

#include "core.h"
#include "if_io.h"
#include "soc.h"
#include "hal.h"
#include "utils.h"
#include "platform.h"
#include "hal_io.h"

struct hal_priv *hpriv;
bool m0_jtag_enable = false;

static int fw_bring_up(void *p)
{
	struct hal_priv *priv = (struct hal_priv *)p;

	if (hpriv->fw_error_processing) {
		rk912_poweron();
		mdelay(RK912_POWER_ON_DELAY_MS);
		platform_bus_rec_init(priv->io_info);
		mdelay(RK912_POWER_ON_DELAY_MS);
	} else {
		if (platform_bus_init(priv->io_info)) {
			RPU_ERROR_MAIN("%s: platform_bus_init failed\n", __func__);
			return -1;
		}
	}

	if (rk912_download_firmware(priv)) {
		RPU_ERROR_MAIN("%s: rk912_download_firmware failed\n", __func__);
		return -1;
	}

	if (rk912_io_init(priv)) {
		RPU_ERROR_MAIN("%s: rk912_io_init failed\n", __func__);
		return -1;
	}

	if (!down_fw_in_probe && !hpriv->fw_error_processing) {
		if (rk912_register_irq(priv->io_info)) {
			RPU_ERROR_MAIN("%s: rk912_irq_register failed\n", __func__);
			return -1;
		}
	}

	return 0;
}

static int fw_tear_down(void *p)
{
	if (hpriv->fw_error_processing) {
		rk912_poweroff();
		return 0;
	}

	platform_bus_deinit(hpriv->io_info);

	return 0;
}

static int rk912_core_init(void)
{
	struct host_io_info *host = NULL;
	struct hal_priv *priv = NULL;

	RPU_INFO_MAIN("%s.\n", __func__);

	host = kzalloc(sizeof(struct host_io_info), GFP_KERNEL);
	if (!host) {
		RPU_ERROR_MAIN("%s: kalloc hal_priv failed\n", __func__);
		goto err;
	}

	host->rx_serias_buf = kzalloc(MAX_RX_SERIAS_BYTES, GFP_KERNEL);
	if (!host->rx_serias_buf) {
		RPU_ERROR_MAIN("%s: kalloc hal_priv failed\n", __func__);
		goto err;
	}

	host->rx_serias_idx = -1;
	host->rx_serias_count = 0;
	host->rx_next_len = 0;
	host->bus_init = false;

	if (rk912_alloc_firmware_buf(&host->firmware) != 0) {
		RPU_ERROR_MAIN("%s: rk912_alloc_firmware_buf failed\n", __func__);
		goto err;
	}

	priv = kzalloc(sizeof(struct hal_priv), GFP_KERNEL);
	if (!priv) {
		RPU_ERROR_MAIN("%s: kalloc hal_priv failed\n", __func__);
		goto err;
	}

	hpriv = priv;
	priv->io_info = host;

	if (platform_bus_init(priv->io_info)) {
		RPU_ERROR_MAIN("%s: platform_bus_init failed\n", __func__);
		goto err;
	}

	return 0;

err:
	if (host)
		rk912_free_firmware_buf(&host->firmware);
	if (host && host->rx_serias_buf)
		kfree(host->rx_serias_buf);
	if (priv)
		kfree(priv);
	if (host)
		kfree(host);

	return -1;
}

int rk912_probe(struct platform_device *pdev)
{
	int ret;
	struct host_io_info *host = hpriv->io_info;

	RPU_INFO_MAIN("%s\n", __func__);

	if (down_fw_in_probe) {
		if (fw_bring_up(hpriv)) {
			RPU_ERROR_MAIN("%s: fw_bring_up failed\n", __func__);
			return -1;
		}
	}

	hpriv->fw_bring_up_func = fw_bring_up;
	hpriv->fw_tear_down_func = fw_tear_down;

	/* Initialize the rest of the layer */
	ret = hal_ops.init(host->dev);
	if (ret < 0) {
		RPU_ERROR_MAIN("%s: hal_ops.init failed\n", __func__);
		return -1;
	}

	if (down_fw_in_probe) {
		if (rk912_register_irq(hpriv->io_info)) {
			RPU_ERROR_MAIN("%s: rk912_irq_register failed\n", __func__);
			return -1;
		}
	}

	return 0;
}

int rk912_remove(struct platform_device *pdev)
{
	RPU_INFO_MAIN("%s\n", __func__);

	hal_ops.deinit(NULL);

	rk912_free_irq(hpriv->io_info);

	return 0;
}

void rk912_shutdown(struct platform_device *pdev)
{
	//RPU_INFO_MAIN("%s\n", __func__);
	hpriv->shutdown = 1;
}

static const struct platform_device_id rk912_id_table[] = {
    {
        .name = "rk912",
        .driver_data = 0x00,
    },
    {},
};
MODULE_DEVICE_TABLE(platform, rk912_id_table);

static struct platform_driver rk912_driver =
{
    .probe = rk912_probe,
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
    .remove = __devexit_p(rk912_remove),
#else
    .remove = rk912_remove,
#endif
    .shutdown = rk912_shutdown,
    .id_table = rk912_id_table,
    .driver = {
        .name = "Rockchip rk912 wifi driver",
        .owner = THIS_MODULE,
    }
};

static int __init rk912_init(void)
{
	int ret;

	RPU_INFO_MAIN("=======================================================\n");
	RPU_INFO_MAIN("==== Launching Wi-Fi driver! (Powered by Rockchip) ====\n");
	RPU_INFO_MAIN("=======================================================\n");
	RPU_INFO_MAIN("RK912 WiFi Ver: %s\n", VERSION_INFO);
	RPU_INFO_MAIN("Build time: %s %s\n", __DATE__, __TIME__);

	ret = rk912_bus_register_driver();
	if (ret) {
		RPU_ERROR_MAIN("%s: rk912_bus_register_driver failed\n", __func__);
		goto error;
	}

	ret = platform_driver_register(&rk912_driver);
	if (ret) {
		RPU_ERROR_MAIN("%s: rk912_platform_driver_register failed\n", __func__);
		goto error1;
	}

	ret = rk912_core_init();
	if (ret) {
		RPU_ERROR_MAIN("%s: rk912_core_init failed\n", __func__);
		goto error2;
	}

	return ret;
error2:
	platform_driver_unregister(&rk912_driver);
error1:
	rk912_bus_unregister_driver();
error:
	return ret;
}

static void __exit rk912_exit(void)
{
	RPU_INFO_MAIN("==========================================================\n");
	RPU_INFO_MAIN("==== Dislaunching Wi-Fi driver! (Powered by Rockchip) ====\n");
	RPU_INFO_MAIN("==========================================================\n");

	platform_driver_unregister(&rk912_driver);

	rk912_bus_unregister_driver();

	platform_bus_deinit(hpriv->io_info);

	rk912_free_firmware_buf(&hpriv->io_info->firmware);

	/* Free private structure */
	if (hpriv->io_info->rx_serias_buf)
		kfree(hpriv->io_info->rx_serias_buf);
	if (hpriv->io_info)
		kfree(hpriv->io_info);
	if (hpriv)
		kfree(hpriv);
	hpriv = NULL;
}

module_init(rk912_init);
module_exit(rk912_exit);

module_param_named(jtag, m0_jtag_enable, bool, 0644);
MODULE_AUTHOR("Rockchips");
MODULE_DESCRIPTION("Driver for Rockchips RK912 SDIO WiFi Devices");
MODULE_LICENSE("GPL");
