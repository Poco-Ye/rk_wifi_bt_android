/*
 * Copyright (c) 2011-2017 Imagination Technologies Ltd.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
#include "core.h"
#include "soc.h"

void program_rpu_dma_start(struct hal_priv *priv) 
{
	return;
}

void clock_init(struct hal_priv *priv)
{
	return;
}
void clock_deinit(struct hal_priv *priv)
{
	return;
}



int parse_dtb_config (struct hal_priv *priv)
{
	return 0;
}



void config_mem_region(unsigned int addr)
{

}

struct soc_ops_tag soc_ops = {
	.program_rpu_dma_start = program_rpu_dma_start,
	.parse_dtb = parse_dtb_config,
	.clock_init = clock_init,
	.clock_deinit = clock_deinit,
	.set_mem_region = config_mem_region,
};

