/*
 * Copyright (c) 2011-2017 Imagination Technologies Ltd.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <linux/version.h>

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/netdevice.h>
#include <linux/proc_fs.h>

#include <asm/unaligned.h>

#include <linux/time.h>
#include <linux/sort.h>
#include <linux/etherdevice.h>
#include <linux/pci-aspm.h>

#include "core.h"
#include "hal.h"
#include "soc.h"
#include "utils.h"

#include <linux/of.h>
#include <linux/of_net.h>
#include <linux/of_device.h>
#include <linux/module.h>
#include <linux/clk.h>
#include <linux/iio/consumer.h>
#include <linux/syscore_ops.h>

/* Supported Vendor ID (IMG) */
#define DEFAULT_IMGPCI_VENDOR_ID		0x0700
#define DEFAULT_IMGPCI_DEVICE_ID		PCI_ANY_ID
#define DRV_NAME "imgpcie"

unsigned long pci_bar_addr;
struct hal_priv *hpriv;
int num_streams_vpd;
unsigned char *rf_params_vpd;
enum PROBE_STATUS probe_status;



void read_mem_region(unsigned int base_addr, int no_words)
{
	int i = 0;
	unsigned int mem_map2 = 0;

        mem_map2 = pci_bar_addr + base_addr;
        for (i = 0;i < no_words; i++) {
		unsigned int addr = mem_map2 + i *4;
		pr_err("Addr: %x Val:%x \n", (i * 4),*((unsigned int *)(unsigned long)addr));
	}
}


struct device *hal_get_dev(void)
{
	struct pci_dev *pdev = NULL;

	pdev = hpriv->bus_dev;
	return &pdev->dev;
}

static int img_pcie_probe(struct pci_dev *pdev,
			  const struct pci_device_id *ent)
{
	void __iomem *vmem_addr_start = NULL;
	int rc;
	unsigned int mem_start, mem_end, mem_len;

	probe_status = PROBE_CALLED;

	rc = pci_enable_device(pdev);

	if (rc < 0) {
		pr_err("PCIE dev enable failure\n");
		goto err_out_free_dev;
	}

	if (!(pci_resource_flags(pdev, 0) & IORESOURCE_MEM)) {
		pr_err("Error: Can't read RPU PCIE resource flags\n");
		goto err_out_disable_pdev;
	}

	rc = pci_request_regions(pdev, DRV_NAME);

	if (rc) {
		pr_err("Error: Can't obtain PCIE resources\n");
		goto err_out_disable_pdev;
	}

	rc = pci_set_dma_mask(pdev, 0x00ffffff);

	if (rc) {
		pr_err("No usable DMA configuration\n");
		goto err_out_free_res;
	}

	mem_start = pci_resource_start(pdev, 0);
	mem_end = pci_resource_end(pdev, 0);
	mem_len = pci_resource_len(pdev, 0);

	vmem_addr_start = ioremap_nocache(mem_start, mem_len);

        if (vmem_addr_start == 0) {
                pr_err("%s: ioremap of pci mem_start failed\n",__func__);
                goto err_out_free_res;

        }

	pci_bar_addr=(unsigned long)vmem_addr_start;
	pr_err("mem_map value is %lx %lx",pci_bar_addr, (unsigned long)vmem_addr_start);

	hpriv = kzalloc(sizeof(struct hal_priv), GFP_KERNEL);

	if (!hpriv)
		goto err_out_free_res;

	hpriv->bus_dev = pdev;

	hpriv->rpu_sysbus_base_addr = (unsigned long)(vmem_addr_start) +
				       HAL_HOST_SYSBUS_BASE_OFF;

	hpriv->gram_base_addr = (unsigned long)(vmem_addr_start) +
				HAL_HOST_PKD_GRAM_BASE_OFF;
	/* Assuming this to be 512 KB presently. This value needs to come
	   from the config space of the RPU */
	hpriv->rpu_pkd_gram_len = 0x0007FFFF;

	hpriv->gram_b4_addr = (unsigned long)(vmem_addr_start) +
			      HAL_HOST_B4_GRAM_BASE_OFF;

	rc = pci_enable_msi(pdev);

	if (rc <= 0) {
		hpriv->irq_flags = IRQF_SHARED;
		RPU_DEBUG_HAL("%s: PCI MSI Not Supported\n",__func__);
		rc = 0;
	}

	hpriv->irq = pdev->irq;
	hpriv->irq_flags |= IRQF_NO_SUSPEND;

	if (mac_addr == NULL)
		mac_addr = DEFAULT_MAC_ADDRESS;

	conv_str_to_byte(vif_macs[0], mac_addr, ETH_ALEN);

	img_ether_addr_copy(vif_macs[1], vif_macs[0]);

	/* Set the Locally Administered bit*/
	vif_macs[1][0] |= 0x02;

	/* Increment the MSB by 1 (excluding 2 special bits)*/
	vif_macs[1][0] += (1 << 2);

	/* To support suspend/resume (economy mode)
	 * during probe a wake up capable device will invoke
	 * the below routine with second parameter("can_wakeup" flag)
	 * set to 1.
	 */
	device_init_wakeup(&pdev->dev, 1);

	/* Initialize the rest of the layer */
	rc = hal_ops.init(pdev);

	if (rc < 0)
		goto free_hpriv;

	probe_status = PROBE_SUCCESS;

	return rc;
free_hpriv:
	kfree(hpriv);
err_out_free_res:
	pci_release_regions(pdev);
err_out_disable_pdev:
	pci_disable_device(pdev);
err_out_free_dev:
	probe_status = PROBE_FAILED;
	return rc;
}

void img_pcie_remove(struct pci_dev *pdev)
{
	if (probe_status != PROBE_SUCCESS)
		return;

	if (pdev) {
		hal_ops.deinit(pdev);
#ifndef IMG_PCIE_USE_POLLING
		pci_disable_msi(pdev);
#endif
		/* To support suspend/resume feature (economy mode)
		 * during remove a wake up capable device will invoke
		 * the below routine with second parameter("can_wakeup" flag)
		 * set to 0.
		 */
		device_init_wakeup(&pdev->dev, 0);
		iounmap((void *)pci_bar_addr);
		pci_release_regions(pdev);
		pci_disable_device(pdev);
		pci_set_drvdata(pdev, NULL);
	}
	probe_status = PROBE_INIT;
}


static struct pci_device_id img_pcie_ids[] = {
	{
		.vendor =       DEFAULT_IMGPCI_VENDOR_ID,
		.device =       DEFAULT_IMGPCI_DEVICE_ID,
		.subvendor =    PCI_ANY_ID,
		.subdevice =    PCI_ANY_ID,
	},
	{
		0,
	}
};


static struct pci_driver imgpcie_driver = {
	.name = "imgpcie",
	.id_table = img_pcie_ids,
	.probe = img_pcie_probe,
	.remove    = img_pcie_remove,
};


static int __init imgpcie_init(void)
{
	int ret = 0;

	probe_status = PROBE_INIT;
	ret = pci_register_driver(&imgpcie_driver);

	if (ret) {
		pr_err("IMG PCIE Driver Initialization failed");
		return ret;
	}

	return ret;
}

static void __exit imgpcie_exit(void)
{
	pci_unregister_driver(&imgpcie_driver);
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Imagination Technologies");
MODULE_DESCRIPTION("Driver for IMG RPU WiFi solution");

module_init(imgpcie_init);
module_exit(imgpcie_exit);
