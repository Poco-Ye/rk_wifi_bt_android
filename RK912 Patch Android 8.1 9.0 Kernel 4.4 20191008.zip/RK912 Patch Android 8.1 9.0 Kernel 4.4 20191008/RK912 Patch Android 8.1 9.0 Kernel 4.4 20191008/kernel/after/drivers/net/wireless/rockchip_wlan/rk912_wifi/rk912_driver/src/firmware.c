#include "core.h"
#include "if_io.h"
#include "sdio.h"
#include "hal_io.h"

struct io_cmd {
        unsigned int id;
        unsigned int length;
        unsigned int addr;
};

void rk912_free_firmware_buf(struct firmware_info *fw_info)
{
	RPU_DEBUG_FIRMWARE("%s\n", __func__);

	if (fw_info->fw_data)
		kfree(fw_info->fw_data);
	fw_info->fw_data = NULL;

	if (fw_info->fw_data_check)
		kfree(fw_info->fw_data_check);
	fw_info->fw_data_check = NULL;

	if (fw_info->patch_data)
		kfree(fw_info->patch_data);
	fw_info->patch_data = NULL;

	if (fw_info->patch2_data)
		kfree(fw_info->patch2_data);
	fw_info->patch2_data = NULL;

	if (fw_info->cal_data)
		kfree(fw_info->cal_data);
	fw_info->cal_data = NULL;
}

int rk912_alloc_firmware_buf(struct firmware_info *fw_info)
{
	RPU_DEBUG_FIRMWARE("%s\n", __func__);

	fw_info->fw_data = kmalloc(MAX_FW_BUF_SIZE, GFP_KERNEL);
	if (fw_info->fw_data == NULL) {
		RPU_ERROR_FIRMWARE("alloc fw_data failed\n");
		return -1;
	}

	fw_info->fw_data_check = kmalloc(MAX_FW_BUF_SIZE, GFP_KERNEL);
	if (fw_info->fw_data_check == NULL) {
		RPU_ERROR_FIRMWARE("alloc fw_data_check failed\n");
		return -1;
	}

	fw_info->patch_data = kmalloc(MAX_FW_BUF_SIZE, GFP_KERNEL);
	if (fw_info->patch_data == NULL) {
		RPU_ERROR_FIRMWARE("alloc patch_data failed\n");
		return -1;
	}

	fw_info->patch2_data = kmalloc(MAX_FW_BUF_SIZE, GFP_KERNEL);
	if (fw_info->patch2_data == NULL) {
		RPU_ERROR_FIRMWARE("alloc patch2_data failed\n");
		return -1;
	}

	fw_info->cal_data = kmalloc(RF_CAL_DATA_SIZE, GFP_KERNEL);
	if (fw_info->cal_data == NULL) {
		RPU_ERROR_FIRMWARE("alloc cal_data failed\n");
		return -1;
	}

	return 0;
}

static int rk912_copy_firmware(struct firmware_info *fw_info,
			int fw_size, int patch_size, int patch2_size, int cal_size,
			u8 *fw_data, u8 *patch_data, u8 *patch2_data, u8 *cal_data)
{
	struct rf_cal_hdr *cal_hdr;

	fw_info->fw_size =  ALIGN(fw_size, 4);
#ifdef ENABLE_FW_SPLIT	
	fw_info->patch_size = ALIGN(patch_size , 4);
#endif
	fw_info->patch2_size = ALIGN(patch2_size , 4);
	/* append rf cal data before patch2 */
	if (cal_size)
		fw_info->patch2_size += ALIGN(sizeof(struct rf_cal_hdr) , 4);

	if (fw_info->patch2_size > MAX_FW_BUF_SIZE) {
		return -1;
	}

	RPU_DEBUG_FIRMWARE("%s: fw_info fw_size: %d, patch_size: %d.\n",
				   __func__, fw_info->fw_size, fw_info->patch_size);
	RPU_DEBUG_FIRMWARE("%s: fw_info patch2_size: %d, cal_size: %d.\n",
				   __func__, fw_info->patch2_size, fw_info->cal_size);

	if (fw_data)
		memcpy(fw_info->fw_data, fw_data, fw_size);
#ifdef ENABLE_FW_SPLIT
	if (patch_data)
		memcpy(fw_info->patch_data, patch_data, patch_size);
#endif
	/* append rf cal data before patch2 */
	if (cal_size) {
		RPU_INFO_FIRMWARE("%s: add rf cal data\n", __func__);
		cal_hdr = (struct rf_cal_hdr *)fw_info->patch2_data;
		memcpy(cal_hdr->tag, RF_CAL_TAG, 4);
		cal_hdr->cal_enable = 1;
		cal_hdr->size = ALIGN(sizeof(struct rf_cal_hdr) , 4);
		memcpy(cal_hdr->cal_data, cal_data, RF_CAL_DATA_SIZE);
		memcpy(fw_info->patch2_data + cal_hdr->size,
				patch2_data, patch2_size);
	} else {
		memcpy(fw_info->patch2_data, patch2_data, patch2_size);
	}

	return 0;
}

#if FW_LOADER_FROM_USER_OPEN
static const char * const fw_path[] = {
        "/etc/firmware",
	"/vendor/etc/firmware",
        "/lib/firmware"
};

static int rk912_read_firmware_file(struct firmware_info *fw_info, char *name, u8 *buf, int *len)
{
	int i, find = 0;
	char path[64];
	struct file *file;
	int read, size = 1024;

	for (i = 0; i < ARRAY_SIZE(fw_path); i++) {
		if (!fw_path[i][0])
			continue;

		sprintf(path, "%s/%s", fw_path[i], name);

		file = filp_open(path, O_RDONLY, 0);
		if (IS_ERR(file))
			continue;

		find = 1;
		break;
	}

	if (!find) {
		RPU_ERROR_FIRMWARE("%s: failed to open %s\n", __func__, name);
		return -1;
	}

	*len = 0;
	while (1) {
		read = kernel_read(file, file->f_pos, buf, size);
		if (read <= 0)
			break;

		file->f_pos += read;
		buf += read;
		*len += read;
	}

	filp_close(file, NULL);

	if (*len > MAX_FW_BUF_SIZE) {
		RPU_ERROR_FIRMWARE("%s file exceed max size %d\n", name, *len);
		return -1;
	}

	return 0;
}

static int rk912_get_firmware_from_open(struct host_io_info *host, struct firmware_info *fw_info)
{
	int ret; 

	RPU_INFO_FIRMWARE("firmware and patch file from open\n");

	ret = rk912_read_firmware_file(fw_info, "rk912_fw.bin", fw_info->fw_data, &fw_info->fw_size);
	if (ret < 0)
		return -1;

#ifdef ENABLE_FW_SPLIT
	ret = rk912_read_firmware_file(fw_info, "rk912_patch_cal.bin", fw_info->patch_data, &fw_info->patch_size);
	if (ret < 0)
		return -1;
#endif

	ret = rk912_read_firmware_file(fw_info, "rk912_patch.bin", fw_info->patch2_data, &fw_info->patch2_size);
	if (ret < 0)
		return -1;

	ret = rk912_read_firmware_file(fw_info, RF_CAL_DATA_FILE, fw_info->cal_data, &fw_info->cal_size);
	if (ret < 0) {
		//RPU_INFO_FIRMWARE("%s load error!\n", RF_CAL_DATA_FILE);
		fw_info->cal_size = 0;
	}

	ret = rk912_copy_firmware(fw_info, fw_info->fw_size, fw_info->patch_size,
					fw_info->patch2_size, fw_info->cal_size,
					(u8 *)fw_info->fw_data, (u8 *)fw_info->patch_data,
					(u8 *)fw_info->patch2_data, (u8 *)fw_info->cal_data);
	if (ret < 0) {
		RPU_INFO_FIRMWARE("rk912_copy_firmware failed!\n");
		return -1;
	}

	return 0;
}
#else
static int rk912_get_firmware_from_request(struct host_io_info *host, struct firmware_info *fw_info)
{
	int error, ret = -1;

	RPU_INFO_FIRMWARE("firmware and patch file from request\n");

	error = request_firmware(&fw_info->fw_fw, "rk912_fw.bin", host->dev);
	if (error < 0) {
		RPU_ERROR_FIRMWARE("rk912_fw.bin load error!\n");
		goto exit_request;
	}

#ifdef ENABLE_FW_SPLIT
	error = request_firmware(&fw_info->patch_fw, "rk912_patch_cal.bin", host->dev);
	if (error < 0) {
		RPU_ERROR_FIRMWARE("rk912_patch_cal.bin load error!\n");
		goto exit_request;
	}
#endif

	error = request_firmware(&fw_info->patch2_fw, "rk912_patch.bin", host->dev);
	if (error < 0) {
		RPU_ERROR_FIRMWARE("rk912_patch.bin load error!\n");
		goto exit_request;
	}

	error = request_firmware(&fw_info->cal_fw, RF_CAL_DATA_FILE, host->dev);
	if (error < 0) {
		//RPU_INFO_FIRMWARE("%s load error!\n", RF_CAL_DATA_FILE);
		fw_info->cal_fw = NULL;
	}

	error = rk912_copy_firmware(fw_info, fw_info->fw_fw->size, fw_info->patch_fw->size,
					fw_info->patch2_fw->size, fw_info->cal_fw?fw_info->cal_fw->size:0,
					(u8 *)fw_info->fw_fw->data, (u8 *)fw_info->patch_fw->data,
					(u8 *)fw_info->patch2_fw->data, fw_info->cal_fw?(u8 *)fw_info->cal_fw->data:NULL);
	if (error < 0) {
		RPU_INFO_FIRMWARE("rk912_copy_firmware failed!\n");
		goto exit_request;
	}

	ret = 0;

exit_request:
	if (fw_info->fw_fw)
		release_firmware(fw_info->fw_fw);
#ifdef ENABLE_FW_SPLIT
	if (fw_info->patch_fw)
		release_firmware(fw_info->patch_fw);
#endif
	if (fw_info->patch2_fw)
		release_firmware(fw_info->patch2_fw);
	if (fw_info->cal_fw)
		release_firmware(fw_info->cal_fw);

	return ret;
}
#endif

static int rk912_get_firmware_info(struct host_io_info *host, struct firmware_info *fw_info)
{
	int ret = 0;

	if (fw_info->fw_saved)
		return 0;

#ifdef FW_LOADER_FROM_USER

#if FW_LOADER_FROM_USER_OPEN
	ret = rk912_get_firmware_from_open(host, fw_info);
#else
	ret = rk912_get_firmware_from_request(host, fw_info);
#endif

#else
	RPU_INFO_FIRMWARE("firmware and patch buildin\n");
	fw_info->fw_size = sizeof(fwdata);
	fw_info->fw_data = fwdata;

	fw_info->patch_size = sizeof(rom_patch);
	fw_info->patch_data = rom_patch;
#endif

	return ret;
}

//#define RK912_MEMORY_CHECK
#ifdef RK912_MEMORY_CHECK
static void rk912_mem_check(struct hal_priv *priv)
{
	int i, j, ret;
	u8 val;
	int size = 2*1024;
	u8 *buf_write = NULL, *buf_read = NULL;
	int fail = 0;

	buf_write = kzalloc(size, GFP_KERNEL);
	if (buf_write == NULL)
		goto mem_chk_end;
	buf_read = kzalloc(size, GFP_KERNEL);
	if (buf_read == NULL)
		goto mem_chk_end;

	for (j = 0; j < 2; j++) {
		if (j == 0) {
			val = 0;
		} else {
			val = 0xff;
		}
		memset(buf_write, val, size);
		ret = rk912_data_write(priv, 0, buf_write, size);
		if (ret) {
			RPU_ERROR_FIRMWARE("%s: download fw failed (%d)\n", __func__, ret);
			goto mem_chk_end;
		}

		ret = rk912_data_read(priv, 0, buf_read, size);
		if (ret) {
			RPU_ERROR_FIRMWARE("%s: read fw failed (%d)\n", __func__, ret);
			goto mem_chk_end;
		}

		fail = 0;
		for (i = 0; i < size; i++) {
			if (buf_read[i] != val) {
				RPU_ERROR_FIRMWARE("i: %d, 0x%02x,  0x%02x\n",
							   i, val, buf_read[i]);
				fail++;
			}
		}

		if (fail) {
			RPU_ERROR_FIRMWARE("%s: value(0x%02X) size(%d) failed\n", __func__, val, size);
		} else {
			RPU_INFO_FIRMWARE("%s: value(0x%02X) size(%d)  success\n", __func__, val, size);
		}
	}

mem_chk_end:
	if (buf_write)
		kfree(buf_write);
	if (buf_read)
		kfree(buf_read);
}
#endif

extern bool m0_jtag_enable;

static int rk912_download(struct hal_priv *priv)
{
	int ret, state;
	struct firmware_info *fw = &priv->io_info->firmware;
	struct io_tx_ctrl_info info;
	int delay_ms = 10, count = 0, max_retry = 300;

	priv->during_fw_download = 1;

	if (likely(!m0_jtag_enable)) {
		struct io_cmd scmd;
		int i;
		u8 val;

#ifdef RK912_MEMORY_CHECK
		rk912_mem_check(priv);
		while (1);
#endif

		// 1. download fw first
		RPU_INFO_FIRMWARE("%s: start download firmware size: %d\n", __func__, fw->fw_size);

		ret = rk912_data_write(priv, 0, fw->fw_data, fw->fw_size);
		if (ret) {
			RPU_ERROR_FIRMWARE("%s: download fw failed (%d)\n", __func__, ret);
			goto fail;
		}

		ret = rk912_data_read(priv, 0, fw->fw_data_check, fw->fw_size);
		if (ret) {
			RPU_ERROR_FIRMWARE("%s: read fw failed (%d)\n", __func__, ret);
			goto fail;
		}

		for (i = 0; i < fw->fw_size; i++) {
			if (fw->fw_data_check[i] != fw->fw_data[i]) {
				RPU_ERROR_FIRMWARE("i: %d, 0x%02x,  0x%02x\n",
							   i, fw->fw_data[i], fw->fw_data_check[i]);
			}
		}

		val = memcmp(fw->fw_data, fw->fw_data_check, fw->fw_size);
		if (val) {
			RPU_ERROR_FIRMWARE("%s: check downloaded fw failed\n", __func__);
			ret = -1;
			goto fail;
		} else {
			RPU_DEBUG_FIRMWARE("%s: check downloaded fw ok.\n", __func__);
		}

		scmd.id = IO_START_CMD_ID;
		scmd.length = 4;
		scmd.addr = 0;
		ret = rk912_data_write(priv, IO_START_CMD_ADDR, (void *)&scmd, sizeof(struct io_cmd));
		if (ret) {
			RPU_ERROR_FIRMWARE("%s: start fw failed (%d)\n", __func__, ret);
			goto fail;
		}

		mdelay(20);
	}

	while (1) {
		state = rk912_readb(priv, IO_FW_STATE);
		if (state < 0) {
			ret = -1;
			goto fail;
		}
		if (state == WAIT_PATCH)
			break;
		if (count++ > max_retry)
			break;
		mdelay(delay_ms);
		//if (net_ratelimit())
		//	RPU_INFO_FIRMWARE("wait fw ready (state = %d)\n", state);
	};
	if (count > max_retry) {
		RPU_INFO_FIRMWARE("%s: download firmware failed\n", __func__);
		ret = -1;
		goto fail;
	} else {
		RPU_INFO_FIRMWARE("%s: download firmware success\n", __func__);
	}

	mdelay(50);

#ifdef ENABLE_FW_SPLIT
	/* 2. download patch */
	RPU_DEBUG_FIRMWARE("%s: start download patch\n", __func__);

	memset(&info, 0, sizeof(struct io_tx_ctrl_info));
	info.type = IO_TX_PKT_PATCH;
	info.patch_len = fw->patch_size;

	ret = rk912_writeb(priv, IO_PATCH_LEN_L, (info.patch_len & 0x00ff));
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_writeb(priv, IO_PATCH_LEN_H, (info.patch_len & 0xff00) >> 8);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_data_write(priv, IO_PATCH_ADDR, fw->patch_data, fw->patch_size);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch failed (%d)\n", __func__, ret);
		goto fail;
	}

	count = 0;
	while (1) {
		state = rk912_readb(priv, IO_FW_STATE);
		if (state < 0) {
			ret = -1;
			goto fail;
		}
		if (state >= WAIT_PATCH2)
			break;
		if (count++ > max_retry)
			break;
		mdelay(delay_ms);
		//if (net_ratelimit())
		//	RPU_INFO_FIRMWARE("wait lpw ready (state = %d)\n", state);
	};
	if (count > max_retry) {
		RPU_INFO_FIRMWARE("%s: download patch failed\n", __func__);
		ret = -1;
		goto fail;
	} else {
		RPU_INFO_FIRMWARE("%s: download patch success\n", __func__);
	}
#endif

	/* 3. download patch2 */
	RPU_DEBUG_FIRMWARE("%s: start download patch2\n", __func__);

	memset(&info, 0, sizeof(struct io_tx_ctrl_info));
	info.type = IO_TX_PKT_PATCH;
	info.patch_len = fw->patch2_size;

	ret = rk912_writeb(priv, IO_PATCH_LEN_L, (info.patch_len & 0x00ff));
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_writeb(priv, IO_PATCH_LEN_H, (info.patch_len & 0xff00) >> 8);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_data_write(priv, IO_PATCH_ADDR, fw->patch2_data, fw->patch2_size);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 failed (%d)\n", __func__, ret);
		goto fail;
	}

	count = 0;
	while (1) {
		state = rk912_readb(priv, IO_FW_STATE);
		if (state < 0) {
			ret = -1;
			goto fail;
		}
		if (state >= M0_READY)
			break;
		if (count++ > max_retry)
			break;
		mdelay(delay_ms);
		//if (net_ratelimit())
		//	RPU_INFO_FIRMWARE("wait lpw ready (state = %d)\n", state);
	};
	if (count > max_retry) {
		RPU_INFO_FIRMWARE("%s: download patch2 failed\n", __func__);
		ret = -1;
		goto fail;
	} else {
		RPU_INFO_FIRMWARE("%s: download patch2 success\n", __func__);
	}	

	// clear patch len
	ret = rk912_writeb(priv, IO_PATCH_LEN_L, 0);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_writeb(priv, IO_PATCH_LEN_H, 0);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

fail:
	priv->during_fw_download = 0;
	return ret;
}

/* return 0 means fw download success, otherwise fail */
int rk912_download_firmware(struct hal_priv *priv)
{
	struct host_io_info *host = (struct host_io_info *)priv->io_info;
	struct firmware_info *fw_info;

	fw_info = &(priv->io_info->firmware);

	/* get info of firmware and rompatch */
	if (rk912_get_firmware_info(host, fw_info)) {
		RPU_ERROR_FIRMWARE("%s: get firmeware error!.\n", __func__);
		return -1;
	}

	fw_info->fw_saved = 1;

	return rk912_download(priv);
}

#if defined(LPW_RECOVERY_FROM_RPU)
int rk912_download_firmware_patch_only(struct hal_priv *priv)
{
	struct firmware_info *fw_info;
	struct io_tx_ctrl_info info;	
	int delay_ms = 10, count = 0, max_retry = 300;
	int ret = 0;
	int state;

	fw_info = &(priv->io_info->firmware);

	/* download patch2 */
	RPU_DEBUG_FIRMWARE("%s: start download patch2, patch2_size = %d\n", __func__, fw_info->patch2_size);

	memset(&info, 0, sizeof(struct io_tx_ctrl_info));
	info.type = IO_TX_PKT_PATCH;
	info.patch_len = fw_info->patch2_size;

	count = 0;
	
	while (1) 
	{
		state = rk912_readb(priv, IO_FW_STATE);
		if (state == WAIT_PATCH2)
			break;
		if (count++ > max_retry)
			break;
		mdelay(delay_ms);
		if (net_ratelimit())
			RPU_DEBUG_FIRMWARE("wait lpw changing state to WAIT_PATCH2 (state = %d), count=%d\n", state, count);
	};

	mdelay(50);
	
	ret = rk912_writeb(priv, IO_PATCH_LEN_L, (info.patch_len & 0x00ff));
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_writeb(priv, IO_PATCH_LEN_H, (info.patch_len & 0xff00) >> 8);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_data_write(priv, IO_PATCH_ADDR, fw_info->patch2_data, fw_info->patch2_size);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 failed (%d)\n", __func__, ret);
		goto fail;
	}

	count = 0;
	while (1) {
		state = rk912_readb(priv, IO_FW_STATE);
		if (state >= LPW_READY)
			break;
		if (count++ > max_retry)
			break;
		mdelay(delay_ms);
		//if (net_ratelimit())
		//	RPU_DEBUG_FIRMWARE("wait lpw ready (state = %d), count=%d\n", state, count);
	};
	if (count > max_retry) {
		RPU_INFO_FIRMWARE("%s: download patch2 failed\n", __func__);
		ret = -1;
		goto fail;
	} else {
		RPU_INFO_FIRMWARE("%s: download patch2 success\n", __func__);
	}		

	// clear patch len
	ret = rk912_writeb(priv, IO_PATCH_LEN_L, 0);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

	ret = rk912_writeb(priv, IO_PATCH_LEN_H, 0);
	if (ret) {
		RPU_ERROR_FIRMWARE("%s: downlaod patch2 rk912_writeb failed (%d)\n", __func__, ret);
		goto fail;
	}

fail:	

	return ret;
}
#endif

