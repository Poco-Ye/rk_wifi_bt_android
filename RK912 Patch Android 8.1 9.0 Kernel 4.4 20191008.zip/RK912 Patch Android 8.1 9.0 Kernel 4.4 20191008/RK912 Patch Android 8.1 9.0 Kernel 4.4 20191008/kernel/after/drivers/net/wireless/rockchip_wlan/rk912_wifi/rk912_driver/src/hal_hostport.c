/*
 * Copyright (c) 2011-2017 Imagination Technologies Ltd.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <asm/unaligned.h>

#include <linux/etherdevice.h>
#include <linux/interrupt.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/netdevice.h>
#include <linux/proc_fs.h>
#include <linux/skbuff.h>
#include <linux/slab.h>
#include <linux/sort.h>
#include <linux/syscore_ops.h>
#include <linux/time.h>


#include "core.h"
#include "hal.h"
#include "soc.h"
#include "utils.h"

struct hal_priv *hpriv;
int num_streams_vpd;
unsigned char *rf_params_vpd;
enum PROBE_STATUS probe_status;

struct device *hal_get_dev(void)
{
	struct platform_device *pdev = NULL;

	pdev = hpriv->bus_dev;
	return &pdev->dev;
}

static int hostport_unmap_memory(void *dev)
{
	/* Unmap RPU sysbus memory */
	iounmap((void __iomem *)hpriv->rpu_sysbus_base_addr);
	release_mem_region(hpriv->rpu_sysbus_base, hpriv->rpu_sysbus_len);


	/* Unmap GRAM */
	if (hpriv->gram_b4_addr)
		iounmap((void __iomem *)hpriv->gram_b4_addr);
	if (hpriv->rpu_gram_base) {
		release_mem_region(hpriv->rpu_gram_base,
				   hpriv->rpu_gram_len);
	}
	iounmap((void __iomem *)hpriv->gram_base_addr);
	release_mem_region(hpriv->rpu_pkd_gram_base,
			   hpriv->rpu_pkd_gram_len);

	return 0;
}

static int hostport_map_memory(void *dev)
{
	int err = 0;

	/* Map RPU SYSBUS memory */
	if (!(request_mem_region(hpriv->rpu_sysbus_base,
				 hpriv->rpu_sysbus_len,
				 "rpu"))) {
		pr_err("%s: request_mem_region failed for RPU core region\n",
		       hal_name);
		err = -ENOMEM;
		goto error;
	}

	hpriv->rpu_sysbus_base_addr = (unsigned long)devm_ioremap(dev,
							hpriv->rpu_sysbus_base,
							hpriv->rpu_sysbus_len);

	if (!hpriv->rpu_sysbus_base_addr) {
		pr_err("%s: Ioremap failed for RPU core mem region\n",
			hal_name);
		err = -ENOMEM;
		goto rpu_sysbus_release;
	}

	/* Map RPU PKD GRAM Memory */
	if (!request_mem_region(hpriv->rpu_pkd_gram_base,
				hpriv->rpu_pkd_gram_len,
				"wlan_gram")) {
		pr_err("%s: request_mem_region failed for GRAM\n",
		       hal_name);
		err = -ENOMEM;
		goto rpu_perip_unmap;
	}

	hpriv->gram_base_addr =
		(unsigned long)devm_ioremap(dev, hpriv->rpu_pkd_gram_base,
				       hpriv->rpu_pkd_gram_len);
	if (!hpriv->gram_base_addr) {
		pr_err("%s: Ioremap failed for gram region.\n",
		       hal_name);
		err = -ENOMEM;
		goto rpu_gram_pkd_release;
	}


	/* Map RPU B4 GRAM Memory */
	if (hpriv->rpu_gram_base) {

		/* gram_b4_addr */
		if (!(request_mem_region(hpriv->rpu_gram_base,
				 hpriv->rpu_gram_len,
				 "rpu_gram_base"))) {
			pr_err("%s:rpu_gram_base: request_mem_region failed\n",
			       hal_name);
			err = -ENOMEM;
			goto rpu_gram_unmap;
		}

		hpriv->gram_b4_addr =
			(unsigned long)devm_ioremap(dev, hpriv->rpu_gram_base,
					       hpriv->rpu_gram_len);

		if (!hpriv->gram_b4_addr) {
			pr_err("%s: Ioremap failed for RPU mem region\n",
				hal_name);
			err = -ENOMEM;
			goto rpu_gram_release;
		}
	}

	return err;

rpu_gram_release:
	if (hpriv->rpu_gram_base)
		release_mem_region(hpriv->rpu_gram_base,
				   hpriv->rpu_gram_len);
rpu_gram_unmap:
	iounmap((void __iomem *)hpriv->gram_base_addr);
rpu_gram_pkd_release:
	release_mem_region(hpriv->rpu_pkd_gram_base,
			   hpriv->rpu_pkd_gram_len);
rpu_perip_unmap:
	iounmap((void __iomem *)hpriv->rpu_sysbus_base_addr);
rpu_sysbus_release:
	release_mem_region(hpriv->rpu_sysbus_base,
			   hpriv->rpu_sysbus_len);
error:
	return err;

}


static int rpu_pltfr_probe(struct platform_device *pdev)
{

	int ret = 0;

	probe_status = PROBE_CALLED;

	hpriv = kzalloc(sizeof(struct hal_priv), GFP_KERNEL);

	if (!hpriv)
		return -ENOMEM;

	hpriv->bus_dev = pdev;

	ret = soc_ops.parse_dtb(hpriv);

	if (ret < 0)
		goto free_hpriv;


	soc_ops.clock_init(hpriv);

	/* To support suspend/resume (economy mode)
	 * during probe a wake up capable device will invoke
	 * the below routine with second parameter("can_wakeup" flag)
	 * set to 1.
	 */
	device_init_wakeup(&pdev->dev, 1);

	ret = hostport_map_memory(&pdev->dev);

	if (ret < 0)
		goto free_hpriv;

	ret = hal_ops.init(&pdev->dev);

	if (ret < 0 ) {
		RPU_DEBUG_HAL("rpu wlan driver registration completed");
		goto unmap_all;
	}

	probe_status = PROBE_SUCCESS;

	return ret;

	
unmap_all:
	hostport_unmap_memory(&pdev->dev);
free_hpriv:
	kfree(hpriv);
	hpriv = NULL;

	return ret;
}

static int rpu_pltfr_remove(struct platform_device *pdev)
{
	soc_ops.clock_deinit(hpriv);
	/* To support suspend/resume feature (economy mode)
	 * during remove a wake up capable device will invoke
	 * the below routine with second parameter("can_wakeup" flag)
	 * set to 0.
	 */
	device_init_wakeup(&pdev->dev, 0);

	if (probe_status != PROBE_SUCCESS)
		return 0;

	hostport_unmap_memory(&pdev->dev);
	hal_ops.deinit(NULL);

	return 0;
}

static const struct of_device_id rpu_dt_ids[] = {
	{ .compatible = DT_COMPATIBLE_NAME},
	{/* sentinel */}
};
MODULE_DEVICE_TABLE(of, rpu_dt_ids);

struct platform_driver img_rpu_driver = {
	.probe = rpu_pltfr_probe,
	.remove = rpu_pltfr_remove,
	.driver = {
		.name     = PLAT_DRIVER_NAME,
		.owner    = THIS_MODULE,
		.of_match_table = of_match_ptr(rpu_dt_ids),
	},
};

static int __init hostport_init(void)
{
	int ret = 0;

	probe_status = PROBE_INIT;
	ret = platform_driver_register(&img_rpu_driver);
	if (ret) {
		pr_err("IMG Hostport Driver Initialization failed");
		return ret;
	}

	return ret;
}

static void __exit hostport_exit(void)
{
	platform_driver_unregister(&img_rpu_driver);
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Imagination Technologies");
MODULE_DESCRIPTION("Driver for IMG RPU WiFi solution");

module_init(hostport_init);
module_exit(hostport_exit);
