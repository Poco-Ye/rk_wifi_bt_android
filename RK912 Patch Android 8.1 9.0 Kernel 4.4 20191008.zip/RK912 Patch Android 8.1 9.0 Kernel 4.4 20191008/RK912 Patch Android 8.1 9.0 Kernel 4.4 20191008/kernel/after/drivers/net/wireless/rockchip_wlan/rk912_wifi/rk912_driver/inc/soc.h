/*
 * Copyright (c) 2011-2017 Imagination Technologies Ltd.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef _SOC_H_
#define _SOC_H_

#include <linux/clk.h>
#include <linux/iio/consumer.h>
#include <linux/of.h>
#include <linux/of_net.h>
#include <linux/of_device.h>

#include "utils.h"
#include "hal_common.h"

/*SoC Porting information:
 */

/* Refer: Danube SoC Functional Spec*/
 
/* The below values should be populated in the dtb file for SoC.

 * Configure the RPU view addresses (from: Volt RPU.Technical Reference Manual.pdf)
   in the dtb (they should directly accessible using memory mapped io in Danube SoC). 
   This might change depending on the SoC.

 * Sample entries looks like below
	compatible = "img,pistachio-uccp";
	reg = <0x18480000 0x9000>, <0x184C0000 0x80000>,
	      <0x1a000000 0x00066CC0>;
	reg-names = "uccp_sysbus_base", "uccp_perip_base",
		    "uccp_pkd_gram_base";
	interrupts = <GIC_SHARED 67 IRQ_TYPE_LEVEL_HIGH>;
	interrupt-names = "uccpirq";

 * uccp_sysbus_base ==> Slave Host System Bus (IMG Bus 2.0 compliant)
	interface for connection to an external processor, allowing
	the external processor to access all internal RPU registers
	and GRAM.

 * uccp_perip_base ==> Master External System Bus (IMG Bus 1.0 compliant)
	interface for connection of peripherals that can be controlled by 
	RPU’s internal META LTP processor.

 * uccp_pkd_gram_base ==> Byte Access of GRAM

 * uccp_gram_base ==>  Word Access of GRAM

 * uccpirq ==> IRQ Line assigned to RPU

 */ 
struct soc_ops_tag {
	void (*program_rpu_dma_start)(struct hal_priv *priv);
	void (*clock_init)(struct hal_priv *priv);
	void (*clock_deinit)(struct hal_priv *priv);
	int (*parse_dtb) (struct hal_priv *priv);
	void (*set_mem_region)(unsigned int addr);
};

extern struct soc_ops_tag soc_ops;

/* As per LPW TRM, refer 4.1 section, mapped in FPGA
 */
#ifdef HAL_PCIE
#define WAKEUP_NOW_OFFSET 0x00F10030
#define HP_RPU_READY 0x00F10034
#endif
#ifdef HAL_HOSTPORT
#endif

#endif /* _SOC_H_ */
