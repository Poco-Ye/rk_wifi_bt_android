#ifndef __RK912_PLATFORM_H_
#define __RK912_PLATFORM_H_

void rk912_poweroff(void);
void rk912_poweron(void);
void rk912_rescan_card(unsigned insert);
int platform_bus_init(struct host_io_info *phost);
int platform_bus_rec_init(struct host_io_info *phost);
int platform_bus_deinit(struct host_io_info *phost);
int rk912_register_irq(struct host_io_info *host);
int rk912_free_irq(struct host_io_info *host);
void rk912_irq_enable(int enable);
int rk912_bus_register_driver(void);
void rk912_bus_unregister_driver(void);

#define RK912_POWER_ON_DELAY_MS	20

#endif //__RK912_PLATFORM_H_