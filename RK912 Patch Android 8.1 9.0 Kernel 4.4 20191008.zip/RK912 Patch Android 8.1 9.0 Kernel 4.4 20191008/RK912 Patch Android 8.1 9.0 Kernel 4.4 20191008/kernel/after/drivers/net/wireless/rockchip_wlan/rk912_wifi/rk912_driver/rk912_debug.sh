#!/system/bin/sh

save_file=/data/rk912_debug.txt

log_item()
{
	echo "" >> $save_file
	echo "-------------------------------------------- $1 --------------------------------------------" >> $save_file
	echo "" >> $save_file
}

echo "start dump rk912 debug info ..."

if [ -e $save_file ];then
rm $save_file
fi

# 1
log_item "dmesg -c"
dmesg -c >> $save_file
echo "t" > /proc/sysrq-trigger
echo "w" > /proc/sysrq-trigger
log_item "sysrq-trigger"
dmesg >> $save_file

# 4
#log_item "m0 log"
#cat /proc/net/rk912/fw_log >> $save_file

#echo "get_stats=1" > /proc/net/rk912/params
#sleep 2

# 5
log_item "params"
cat /proc/net/rk912/params >> $save_file

# 6
log_item "hal_stats"
cat /proc/net/rk912/hal_stats >> $save_file
sleep 1
log_item "hal_stats"
cat /proc/net/rk912/hal_stats >> $save_file
sleep 1
log_item "hal_stats"
cat /proc/net/rk912/hal_stats >> $save_file

# 7
log_item "mac_stats"
cat /proc/net/rk912/mac_stats >> $save_file
sleep 1
log_item "mac_stats"
cat /proc/net/rk912/mac_stats >> $save_file
sleep 1
log_item "mac_stats"
cat /proc/net/rk912/mac_stats >> $save_file

# 8
log_item "phy_stats"
cat /proc/net/rk912/phy_stats >> $save_file

# 9
log_item "sleep_stats"
cat /proc/net/rk912/sleep_stats >> $save_file

# 10
log_item "fw_txrx_count_info"
echo "fw_txrx_count_info" > /proc/net/rk912/params
sleep 1
cat /proc/net/rk912/fw_info >> $save_file

# 11
log_item "fw_txrx_queue_info"
echo "fw_txrx_queue_info" > /proc/net/rk912/params
sleep 1
cat /proc/net/rk912/fw_info >> $save_file

# 12
log_item "fw_if_info"
echo "fw_if_info" > /proc/net/rk912/params
sleep 1
cat /proc/net/rk912/fw_info >> $save_file

# 13
log_item "dump ifconfig"
ifconfig >> $save_file

# 14
log_item "arp"
ip n >> $save_file

# 15
log_item "ios"
cat /d/mmc1/ios >> $save_file

#16
droute=""
droute=$(ip route show table wlan0 | grep default | busybox awk '{print $3}')
log_item "ping $droute"
if [ "$droute" != "" ];then
ping -c 1 $droute >> $save_file
fi

#17
log_item "logcat"
logcat -d >> $save_file

# this should at last
log_item "dumpsys wifi"
dumpsys wifi >> $save_file

echo "finish dump, save to $save_file"
