﻿1、用tinyalsa_hal_20200518.zip 直接替换，或者对比打在hardware/rockchip/audio/tinyalsa_hal

2、蓝牙参考android9.0_hfp_modify.patch修改， 33999.0 现在蓝牙是作从，主控提供sync(8k) clock(512K)
