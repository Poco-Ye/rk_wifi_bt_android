1.该patch只是demo供客户参考，实现双wifi（station+ap）；
2.先保证机器自带的wifi连接上路由器，能够正常使用station功能；
3.再运行start_softap.sh脚本，该脚本默认加载8188eu.ko,通过ndc命令开启2.4G热点和nat路由转发功能；


add-softap-related-for-android9.0.patch补丁应用路径：/system/netd


start_softap.sh部分参数解析：

interface=wlan1 //默认作为热点的wifi端口为wlan1
insmod /vendor/lib/modules/8188eu.ko; //默认加载8188eu驱动，客户可以根据自己挑选的wifi加载对应的ko
ndc netd 5001 softap set $interface $ssid broadcast 6 wpa2-psk $passwd  //默认是2.4G热点channel 6，如果选择的模块支持5G并且需要用5G作为热点，可以将6改成153；

